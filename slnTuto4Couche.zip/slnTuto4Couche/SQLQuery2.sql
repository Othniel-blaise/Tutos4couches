﻿CREATE PROCEDURE dbo.SPX_Utilisateur_Insert
(@UserLogin varchar(10),@UserMotPass varchar(10),@UserNomComplet varchar(50), @UserRole varchar(20),@UserEmail
varchar(50))
AS
INSERT INTO Utilisateur
(UserLogin, UserMotPass, UserNomComplet, UserRole, UserEmail)
VALUES
(@UserLogin,@UserMotPass,@UserNomComplet,@UserRole,@UserEmail)
RETURN
GO

CREATE PROCEDURE dbo.SPX_Utilisateur_Update
(@UserLogin varchar(10),@UserMotPass varchar(10),@UserNomComplet varchar(50),@UserRole varchar(20),@UserEmail
varchar(50))
AS
UPDATE Utilisateur
SET
UserMotPass = @UserMotPass, UserNomComplet = @UserNomComplet, UserRole = @UserRole,UserEmail = @UserEmail
WHERE (UserLogin = @UserLogin)
RETURN
GO
CREATE PROCEDURE dbo.SPX_Utilisateur_SelectAll (@UserNomComplet varchar(50))
AS
SELECT Utilisateur. * FROM Utilisateur
WHERE (UserNomComplet LIKE @UserNomComplet + '%')
RETURN
GO
CREATE PROCEDURE dbo.SPX_Utilisateur_Get (@UserLogin varchar(10))
AS
SELECT Utilisateur.* FROM Utilisateur
WHERE (UserLogin = @UserLogin)
RETURN
GO
CREATE PROCEDURE dbo.SPX_Utilisateur_Delete
@UserLogin varchar(10)
AS
DELETE FROM Utilisateur
WHERE (UserLogin = @UserLogin)
RETURN
GO