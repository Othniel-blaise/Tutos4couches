﻿using MetierTuto4Couches;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfaceTuto4Couches
{
    public partial class FrmUtilisateurListe : Form
    {
        public FrmUtilisateurListe()
        {
            InitializeComponent();
            rafraichirList();
        }

        private void rafraichirList()
        {
            lviewRech.Items.Clear();
            DataTable dt = Utilisateur.SelectAll(txtFiltre.Text);
            foreach (DataRow row in dt.Rows)
            {
                string vLogin = "";
                string vNomPrenom = "";
                string vEmail = "";
                string vRole = "";
                string vPass = "";
                if (!DBNull.Value.Equals(row["UserLogin"])) vLogin = (string)row["UserLogin"];
                if (!DBNull.Value.Equals(row["UserMotPass"])) vPass = (string)row["UserMotPass"];
                if (!DBNull.Value.Equals(row["UserNomComplet"])) vNomPrenom = (string)row["UserNomComplet"];
                if (!DBNull.Value.Equals(row["UserRole"])) vRole = (string)row["UserRole"];
                if (!DBNull.Value.Equals(row["UserEmail"])) vEmail = (string)row["UserEmail"];
                ListViewItem itm = lviewRech.Items.Add(vLogin);
                itm.SubItems.Add(vPass);
                itm.SubItems.Add(vNomPrenom);
                itm.SubItems.Add(vRole);
                itm.SubItems.Add(vEmail);
                itm.Tag = vLogin;
            }
            //  lblNbre.Text = lviewRech.Items.Count.ToString() + " utiolisateurs";
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnAjouter_Click(object sender, EventArgs e)
        {
            FrmUtilisateurDetails frm = new
            FrmUtilisateurDetails(null, 'n');
            frm.ShowDialog();
            rafraichirList();
        }

        private void BtnModifier_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                FrmUtilisateurDetails frm = new FrmUtilisateurDetails(leUser, 'm');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void btnConsulter_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                FrmUtilisateurDetails frm = new FrmUtilisateurDetails(leUser, 'c');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void BtnSupprimer_Click(object sender, EventArgs e)
        {
            if (lviewRech.SelectedItems.Count > 0)
            {
                string vid = (string)lviewRech.SelectedItems[0].Tag;
                Utilisateur leUser = new Utilisateur(vid);
                FrmUtilisateurDetails frm = new FrmUtilisateurDetails(leUser, 's');
                frm.ShowDialog();
                rafraichirList();
            }
        }

        private void lviewRech_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmUtilisateurListe_Load(object sender, EventArgs e)
        {

        }

        private void BtnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnActualiser_Click(object sender, EventArgs e)
        {
            InitializeComponent();
        }
    }
}
