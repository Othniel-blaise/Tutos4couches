﻿namespace InterfaceTuto4Couches
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            TextLogin = new TextBox();
            TextePassword = new TextBox();
            cbRole = new ComboBox();
            BtnOK = new Button();
            BtnFermer = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(194, 89);
            label1.Name = "label1";
            label1.Size = new Size(137, 20);
            label1.TabIndex = 0;
            label1.Text = "Nom De connexion";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(230, 137);
            label2.Name = "label2";
            label2.Size = new Size(98, 20);
            label2.TabIndex = 1;
            label2.Text = "Mot De Passe";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(277, 198);
            label3.Name = "label3";
            label3.Size = new Size(39, 20);
            label3.TabIndex = 2;
            label3.Text = "Role";
            label3.Click += label3_Click;
            // 
            // TextLogin
            // 
            TextLogin.Location = new Point(434, 89);
            TextLogin.Name = "TextLogin";
            TextLogin.Size = new Size(182, 27);
            TextLogin.TabIndex = 3;
            // 
            // TextePassword
            // 
            TextePassword.Location = new Point(434, 137);
            TextePassword.Name = "TextePassword";
            TextePassword.Size = new Size(182, 27);
            TextePassword.TabIndex = 4;
            // 
            // cbRole
            // 
            cbRole.FormattingEnabled = true;
            cbRole.Location = new Point(434, 195);
            cbRole.Name = "cbRole";
            cbRole.Size = new Size(182, 28);
            cbRole.TabIndex = 5;
            // 
            // BtnOK
            // 
            BtnOK.Location = new Point(336, 352);
            BtnOK.Name = "BtnOK";
            BtnOK.Size = new Size(94, 29);
            BtnOK.TabIndex = 6;
            BtnOK.Text = "OK";
            BtnOK.UseVisualStyleBackColor = true;
            BtnOK.Click += BtnOK_Click_1;
            // 
            // BtnFermer
            // 
            BtnFermer.Location = new Point(617, 352);
            BtnFermer.Name = "BtnFermer";
            BtnFermer.Size = new Size(94, 29);
            BtnFermer.TabIndex = 7;
            BtnFermer.Text = "Fermer";
            BtnFermer.UseVisualStyleBackColor = true;
            BtnFermer.Click += BtnFermer_Click;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(BtnFermer);
            Controls.Add(BtnOK);
            Controls.Add(cbRole);
            Controls.Add(TextePassword);
            Controls.Add(TextLogin);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FrmLogin";
            Text = "FrmLogin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox TextLogin;
        private TextBox TextePassword;
        private ComboBox cbRole;
        private Button BtnOK;
        private Button BtnFermer;
    }
}