﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetierTuto4Couches;


namespace InterfaceTuto4Couches
{
    public partial class FrmUtilisateurDetails : Form
    {
        char vOptionAppel = 'n'; //attribut permettant de définir le contexte d'appel ('n','m','c','s')
        string vTitre = "";//permet de définir le titre du formulaire en fonction du contexte d'appel
        Utilisateur CurrentUser = null;// objet métier contenant l'utilisateur en cours de traitement
        public FrmUtilisateurDetails()
        {// constructeur par défaut
            InitializeComponent();
            InitForm(vOptionAppel);
        }
        public FrmUtilisateurDetails(Utilisateur LeUser, char pOptionAppel)
        {//Constructeur appelé avec en paramètrel'utilisateur courant et l'option d'appel
            InitializeComponent();
            CurrentUser = LeUser;//réccupération de l'utilisateur courant dans l'attribut CurrentUser
            vOptionAppel = pOptionAppel; //affectation de l'option d'appel dans l'attribut vOptionAppel
            InitForm(vOptionAppel);// méthode d'initialisation du titre et des contrôles du formulaire selon l'option d'appel
                                   // ChargerLeUser(LeUser);//méthode d'affichage de l'utilisateur en cours de traitement
        }




        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmUtilisateurDetails_Load(object sender, EventArgs e)
        {

        }
        /*private void ChargerLeUser(Utilisateur LeUser)
        {
            if (LeUser != null)
            {
                // Vérification et affectation des propriétés de l'utilisateur aux champs du formulaire
                if (!string.IsNullOrEmpty(LeUser.Login))
                {
                    txtLogin.Text = LeUser.Login;
                }

                if (!string.IsNullOrEmpty(LeUser.MotDePasse))
                {
                    txtMotdepasse.Text = LeUser.MotDePasse;
                }

                if (!string.IsNullOrEmpty(LeUser.NomPrenom))
                {
                    txtNom.Text = LeUser.NomPrenom;
                }

                if (!string.IsNullOrEmpty(LeUser.Role))
                {
                    cbUserRole.Text = LeUser.Role;
                }

                if (!string.IsNullOrEmpty(LeUser.Email))
                {
                    txtEmail.Text = LeUser.Email;
                }
            }
            else
            {
                // Réinitialisation des champs si LeUser est nul
                txtLogin.Text = string.Empty;
                txtMotdepasse.Text = string.Empty;
                txtNom.Text = string.Empty;
                cbUserRole.Text = string.Empty;
                txtEmail.Text = string.Empty;
            }
        }*/



        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            if (OkSaisie())
            {
                MappFormToObject();
                switch (vOptionAppel)
                {
                    case 'n':
                        if (!Divers.ExisteUtilisateur(txtLogin.Text))
                        {
                            CurrentUser.Insert();
                            MessageBox.Show("l'Utilisateur a été enregistré ", Application.ProductName, MessageBoxButtons.OK);
                        }
                        else MessageBox.Show("Risque de doublon. la saisie ne sera pas enregistrée ", Application.ProductName, MessageBoxButtons.OK);
                        break;
                    case 'c':
                        break;
                    case 'm':
                        if (Divers.ExisteUtilisateur(txtLogin.Text))
                        {
                            /* CurrentUser.Update();
                             MessageBox.Show("Les modifications ont été enregistrées ", Application.ProductName, MessageBoxButtons.OK);*/
                        }
                        else
                        {
                            MessageBox.Show("code utilisateur inexistant! les modifications ont été ignorées", Application.ProductName, MessageBoxButtons.OK);
                        }
                        break;
                    case 's':
                        CurrentUser.Supprimer(txtLogin.Text);
                        MessageBox.Show("L'utilisateur a été désactivé", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    default:
                        break;
                }
                this.Close();
            }
        }
        private void MappFormToObject()
        {// méthode MappFormToObject() qui affecte la saisie à l'objet utilisateur de la classe métier
            CurrentUser = new Utilisateur();
            CurrentUser.UserLogin = txtLogin.Text;
            CurrentUser.UserMotPass = txtMotPass.Text;
            CurrentUser.UserNomComplet = txtNomPrenom.Text;
            if (cbRole.Text.Length > 0)
            {
                CurrentUser.UserRole = cbRole.Text;
            }
            CurrentUser.UserEmail = txtEmail.Text;
        }
        private void InitForm(char optionAppel)
        {
            switch (optionAppel)
            {
                case 'n':
                    vTitre = "Nouvel utilisateur";
                    // Configuration des contrôles pour un nouvel utilisateur
                    break;
                case 'm':
                    vTitre = "Modifier utilisateur";
                    // Configuration des contrôles pour la modification d'un utilisateur
                    break;
                case 'c':
                    vTitre = "Consulter utilisateur";
                    // Configuration des contrôles pour la consultation d'un utilisateur
                    break;
                case 's':
                    vTitre = "Supprimer utilisateur";
                    // Configuration des contrôles pour la suppression d'un utilisateur
                    break;
                default:
                    vTitre = "Détail utilisateur";
                    // Configuration par défaut
                    break;
            }
            this.Text = vTitre; // Mise à jour du titre de la fenêtre
        }

        private bool OkSaisie()
        {/* méthode OkSaisie() de contrôle de la régularité de la saisie de l'utilisateur
* qui souhaite veut enregistrer sa saisie par click sur le bouton btnEnregistrer
*/
            if (string.IsNullOrEmpty(txtLogin.Text))
            {
                MessageBox.Show("login d'utilisateur attendu", Application.ProductName, MessageBoxButtons.OK);
                txtLogin.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtMotPass.Text))
            {
                MessageBox.Show("Mot de passe attendu", Application.ProductName, MessageBoxButtons.OK);
                txtMotPass.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtNomPrenom.Text))
            {
                MessageBox.Show("Nom et prenoms de l'utilisateur attendu", Application.ProductName, MessageBoxButtons.OK);
                txtNomPrenom.Focus();
                return false;
            }
            return true;
        }

        private void Fermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
