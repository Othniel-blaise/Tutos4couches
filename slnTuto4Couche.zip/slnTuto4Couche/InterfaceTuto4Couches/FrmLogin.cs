﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InterfaceTuto4Couches
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BtnOk_Click(object sender, EventArgs e)
        {

        }

        private void BtnFermer_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnOK_Click_1(object sender, EventArgs e)
        {
            /*if (TextLogin.Text.ToUpper() == "Esty" && TextePassword.Text.ToUpper() == "Esty")
            {*/
                FrmMenuPrincipal frm = new FrmMenuPrincipal();
                frm.ShowDialog();
          /*  }
            else MessageBox.Show("Login ou mot de passe incorrect", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information);
*/
        }
    }
}
