﻿namespace InterfaceTuto4Couches
{
    partial class FrmUtilisateurDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtLogin = new TextBox();
            txtMotPass = new TextBox();
            txtNomPrenom = new TextBox();
            txtEmail = new TextBox();
            btnEnregistrer = new Button();
            Fermer = new Button();
            cbRole = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(120, 77);
            label1.Name = "label1";
            label1.Size = new Size(87, 20);
            label1.TabIndex = 0;
            label1.Text = "Login name";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(120, 138);
            label2.Name = "label2";
            label2.Size = new Size(96, 20);
            label2.TabIndex = 1;
            label2.Text = "Mot de Passe";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(120, 200);
            label3.Name = "label3";
            label3.Size = new Size(121, 20);
            label3.TabIndex = 2;
            label3.Text = "Nom et prénoms";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(129, 251);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 3;
            label4.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(120, 301);
            label5.Name = "label5";
            label5.Size = new Size(120, 20);
            label5.TabIndex = 4;
            label5.Text = "Role d'utilisateur";
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(312, 74);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(227, 27);
            txtLogin.TabIndex = 5;
            // 
            // txtMotPass
            // 
            txtMotPass.Location = new Point(312, 131);
            txtMotPass.Name = "txtMotPass";
            txtMotPass.Size = new Size(227, 27);
            txtMotPass.TabIndex = 6;
            // 
            // txtNomPrenom
            // 
            txtNomPrenom.Location = new Point(312, 193);
            txtNomPrenom.Name = "txtNomPrenom";
            txtNomPrenom.Size = new Size(227, 27);
            txtNomPrenom.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(312, 244);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(227, 27);
            txtEmail.TabIndex = 8;
            // 
            // btnEnregistrer
            // 
            btnEnregistrer.Location = new Point(353, 395);
            btnEnregistrer.Name = "btnEnregistrer";
            btnEnregistrer.Size = new Size(94, 29);
            btnEnregistrer.TabIndex = 10;
            btnEnregistrer.Text = "Enregistrer";
            btnEnregistrer.UseVisualStyleBackColor = true;
            btnEnregistrer.Click += btnEnregistrer_Click;
            // 
            // Fermer
            // 
            Fermer.Location = new Point(538, 395);
            Fermer.Name = "Fermer";
            Fermer.Size = new Size(94, 29);
            Fermer.TabIndex = 11;
            Fermer.Text = "btnFermer";
            Fermer.UseVisualStyleBackColor = true;
            Fermer.Click += Fermer_Click;
            // 
            // cbRole
            // 
            cbRole.FormattingEnabled = true;
            cbRole.Location = new Point(312, 301);
            cbRole.Name = "cbRole";
            cbRole.Size = new Size(227, 28);
            cbRole.TabIndex = 12;
            // 
            // FrmUtilisateurDetails
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cbRole);
            Controls.Add(Fermer);
            Controls.Add(btnEnregistrer);
            Controls.Add(txtEmail);
            Controls.Add(txtNomPrenom);
            Controls.Add(txtMotPass);
            Controls.Add(txtLogin);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FrmUtilisateurDetails";
            Text = "FrmUtilisateurDetails";
            Load += FrmUtilisateurDetails_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtLogin;
        private TextBox txtMotPass;
        private TextBox txtNomPrenom;
        private TextBox txtEmail;
        private Button btnEnregistrer;
        private Button Fermer;
        private ComboBox cbRole;
    }
}