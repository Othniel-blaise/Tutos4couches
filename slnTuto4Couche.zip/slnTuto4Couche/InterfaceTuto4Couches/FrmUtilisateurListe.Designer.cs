﻿namespace InterfaceTuto4Couches
{
    partial class FrmUtilisateurListe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lviewRech = new ListView();
            Login = new ColumnHeader();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            BtnFermer = new Button();
            BtnSupprimer = new Button();
            btnConsulter = new Button();
            BtnModifier = new Button();
            BtnAjouter = new Button();
            txtFiltre = new TextBox();
            btnActualiser = new Button();
            NomEtud = new Label();
            SuspendLayout();
            // 
            // lviewRech
            // 
            lviewRech.Columns.AddRange(new ColumnHeader[] { Login, columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            lviewRech.FullRowSelect = true;
            lviewRech.GridLines = true;
            lviewRech.Location = new Point(12, 128);
            lviewRech.Name = "lviewRech";
            lviewRech.Size = new Size(872, 416);
            lviewRech.TabIndex = 0;
            lviewRech.UseCompatibleStateImageBehavior = false;
            lviewRech.View = View.Details;
            lviewRech.SelectedIndexChanged += lviewRech_SelectedIndexChanged;
            // 
            // Login
            // 
            Login.Text = "Login";
            Login.Width = 100;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Mot de Passe";
            columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Nom et Prénoms";
            columnHeader2.Width = 300;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Role";
            columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "E-mail";
            columnHeader4.Width = 110;
            // 
            // BtnFermer
            // 
            BtnFermer.Location = new Point(780, 550);
            BtnFermer.Name = "BtnFermer";
            BtnFermer.Size = new Size(94, 29);
            BtnFermer.TabIndex = 9;
            BtnFermer.Text = "Fermer";
            BtnFermer.UseVisualStyleBackColor = true;
            BtnFermer.Click += BtnFermer_Click;
            // 
            // BtnSupprimer
            // 
            BtnSupprimer.Location = new Point(647, 550);
            BtnSupprimer.Name = "BtnSupprimer";
            BtnSupprimer.Size = new Size(94, 29);
            BtnSupprimer.TabIndex = 8;
            BtnSupprimer.Text = "Supprimer";
            BtnSupprimer.UseVisualStyleBackColor = true;
            BtnSupprimer.Click += BtnSupprimer_Click;
            // 
            // btnConsulter
            // 
            btnConsulter.Location = new Point(531, 550);
            btnConsulter.Name = "btnConsulter";
            btnConsulter.Size = new Size(94, 29);
            btnConsulter.TabIndex = 11;
            btnConsulter.Text = "Consulter";
            btnConsulter.UseVisualStyleBackColor = true;
            btnConsulter.Click += btnConsulter_Click;
            // 
            // BtnModifier
            // 
            BtnModifier.Location = new Point(411, 550);
            BtnModifier.Name = "BtnModifier";
            BtnModifier.Size = new Size(94, 29);
            BtnModifier.TabIndex = 10;
            BtnModifier.Text = "Modifier";
            BtnModifier.UseVisualStyleBackColor = true;
            BtnModifier.Click += BtnModifier_Click;
            // 
            // BtnAjouter
            // 
            BtnAjouter.Location = new Point(283, 550);
            BtnAjouter.Name = "BtnAjouter";
            BtnAjouter.Size = new Size(94, 29);
            BtnAjouter.TabIndex = 12;
            BtnAjouter.Text = "Ajouter";
            BtnAjouter.UseVisualStyleBackColor = true;
            BtnAjouter.Click += BtnAjouter_Click;
            // 
            // txtFiltre
            // 
            txtFiltre.Location = new Point(446, 74);
            txtFiltre.Name = "txtFiltre";
            txtFiltre.Size = new Size(322, 27);
            txtFiltre.TabIndex = 13;
            // 
            // btnActualiser
            // 
            btnActualiser.Location = new Point(780, 74);
            btnActualiser.Name = "btnActualiser";
            btnActualiser.Size = new Size(94, 29);
            btnActualiser.TabIndex = 14;
            btnActualiser.Text = "Actualiser";
            btnActualiser.UseVisualStyleBackColor = true;
            btnActualiser.Click += btnActualiser_Click;
            // 
            // NomEtud
            // 
            NomEtud.AutoSize = true;
            NomEtud.Location = new Point(194, 77);
            NomEtud.Name = "NomEtud";
            NomEtud.Size = new Size(203, 20);
            NomEtud.TabIndex = 15;
            NomEtud.Text = "Nom d'étudiant commençant";
            // 
            // FrmUtilisateurListe
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(896, 587);
            Controls.Add(NomEtud);
            Controls.Add(btnActualiser);
            Controls.Add(txtFiltre);
            Controls.Add(BtnAjouter);
            Controls.Add(btnConsulter);
            Controls.Add(BtnModifier);
            Controls.Add(BtnFermer);
            Controls.Add(BtnSupprimer);
            Controls.Add(lviewRech);
            Name = "FrmUtilisateurListe";
            Text = "FrmUtilisateurListe";
            Load += FrmUtilisateurListe_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView lviewRech;
        private Button BtnFermer;
        private Button BtnSupprimer;
        private Button btnConsulter;
        private Button BtnModifier;
        private Button BtnAjouter;
        private TextBox txtFiltre;
        private Button btnActualiser;
        private Label NomEtud;
        private ColumnHeader Login;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
    }
}