using System;

namespace MetierTuto4Couches
{
    public class Class1
    {
    }
}
