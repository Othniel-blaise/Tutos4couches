﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonTutu4Couches;
using DataAccessTuto4Couche;
using System.Data;

namespace MetierTuto4Couches
{
    public class Utilisateur
    {
        //Définition des attributs
        string _UserLogin;
        string _UserMotPass;
        string _UserNomComplet;
        string _UserRole;
        string _UserEmail;
        //Définition des propriétés ou accesseurs
        public string UserLogin
        {
            get { return _UserLogin; }
            set { _UserLogin = value; }
        }
        public string UserMotPass
        {
            get { return _UserMotPass; }
            set { _UserMotPass = value; }
        }
        public string UserNomComplet
        {
            get { return _UserNomComplet; }
            set { _UserNomComplet = value; }
        }
        public string UserRole
        {
            get { return _UserRole; }
            set { _UserRole = value; }
        }
        public string UserEmail
        {
            get { return _UserEmail; }
            set { _UserEmail = value; }
        }
        strUtilisateur MyStructure
        {
            get
            {
                strUtilisateur st = new strUtilisateur();
                st.UserLogin = this._UserLogin;
                st.UserMotPass = this._UserMotPass;
                st.UserNomComplet = this._UserNomComplet;
                st.UserRole = this._UserRole;
                st.UserEmail = this._UserEmail;
                return st;
            }
        }
        public void MapFromDataReader(IDataReader dreader)
        {
            if (!(DBNull.Value.Equals(dreader["UserLogin"])))
            {
                _UserLogin = (string)dreader["UserLogin"];
            }
            if (!(DBNull.Value.Equals(dreader["UserMotPass"])))
            {
                _UserMotPass = (string)dreader["UserMotPass"];
            }
            if (!(DBNull.Value.Equals(dreader["UserNomComplet"])))
            {
                _UserNomComplet = (string)dreader["UserNomComplet"];
            }
            if (!(DBNull.Value.Equals(dreader["UserRole"])))
            {
                _UserRole = (string)dreader["UserRole"];
            }
            if (!(DBNull.Value.Equals(dreader["UserEmail"])))
            {
                _UserEmail = (string)dreader["UserEmail"];
            }
        }
        public static DataTable SelectAll(string pUserNom)
        {
            dbUtilisateur undbUser = new dbUtilisateur();
            DataTable dt = undbUser.SelectAll(pUserNom);
            return dt;
        }
        public void Insert()
        {
            dbUtilisateur undbuser = new dbUtilisateur();
            undbuser.Insert(this.MyStructure);
        }
      /*  public void Update()
        {
            dbUtilisateur undbUser = new dbUtilisateur();
            undbUser.Update(this.MyStructure);
        }*/
        public void Supprimer(string pLogin)
        {
            dbUtilisateur undbUser = new dbUtilisateur();
            undbUser.Supprimer(pLogin);
        }
        public Utilisateur(string pLogin)
        {
            dbUtilisateur db = new dbUtilisateur();
            IDataReader dreader = db.GetObject(pLogin); ;
            if (dreader.Read())
            {
                this.MapFromDataReader(dreader);
            }
            db.CloseConnexion();
        }
        public Utilisateur()
        { }
    }
}
