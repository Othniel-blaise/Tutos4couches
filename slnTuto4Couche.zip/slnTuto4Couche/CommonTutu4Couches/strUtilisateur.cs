﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonTutu4Couches
{
    
    
        public struct strUtilisateur
        {
            public string UserLogin;
            public string UserMotPass;
            public string UserNomComplet;
            public string UserRole;
            public string UserEmail;
        }
    
}
