using System;

namespace DataAccessTuto4Couche
{
    public class Class1
    {
    }
}
